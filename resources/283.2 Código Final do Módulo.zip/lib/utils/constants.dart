class Constants {
  static const BASE_API_URL = 'https://flutter-cod3r-2e9fd.firebaseio.com/';
}